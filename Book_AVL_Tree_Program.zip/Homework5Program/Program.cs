﻿//Name: Kevin Flores
//Class: CS3345
//Date: 10/20/2018
//
//Note: Will order by ISBN number. Throughout this code key is the same as ISBN number

//these are some namespaces that are referenceable in this code
using System;
using System.IO;
using System.Text;
using static System.IO.Directory;

namespace Homework5Program
{
    //Where requirements of the code is tested (where the magic happens)
    class CenterStage
    {
        static void Main(string[] args)
        {
            //read from books.txt
            string[] lines;
            string[] words = null;
            string wd = (GetCurrentDirectory()) + "/bin/books.txt";
            Console.WriteLine(wd);
            Console.WriteLine(File.Exists(wd) ? "Books.txt file exists." : "Books.txt file does not exist.");
            lines = File.ReadAllLines(wd);

            //generate a new emptytree
            AVLTree example = new AVLTree();

            Console.WriteLine(lines[0]);
            Console.WriteLine(lines.Length);
            //fill in the tree
            for(int i = 0; i < lines.Length; i++ )
            {
            
                Console.WriteLine("Using line " + (i+1) + ": " + lines[i]);
                string line = lines[i];
                words = line.Split(" ");
                example.insert(words);
            }
        }
    }

    //AVLTree class
    class AVLTree
    {
        //initalize a root node
        public Node root;
        //initalize the tree
        public AVLTree()
        {
            root = null;
        }
        //checks if tree is empty
        public bool isEmpty()
        {
          return root == null;  
        }
        //inserts a node upon tree
        public void insert(string[] words)
        {
            int key = Convert.ToInt32(words[0]);
            if (isEmpty())
            {//starts an empty tree, allows the program to inform the user about progress
                Console.WriteLine("Inserting " + key);
                Console.WriteLine("Tree is empty");
                root = new Node(words, key);
                Console.WriteLine("Insertion done");
            }
            else
            {
                //Informs the user about progress of insertion, which at this point is using a node-function
                Console.WriteLine("Inserting " + key);
                root.InsertNewData(ref root, words, key);
                
            }

        }

       public void DisplayRootHeight()
        {// This is used to display final height of the root, although mainly for debugging purposes
            Console.WriteLine(root.height);
        }

    }

    class Book
    {//The required book node with its characteristics
        string authorName;
        string title;
        string ISBNkey;

        public Book(string[] words)
        {
            ISBNkey = words[0];
            title = words[1];
            authorName = words[2];
        }
    } 

    class Node
    {
        //variables
        public Book thisBook;
        public int key;
        //every new node begins with these values
        public int height = 0;
        public int balanceFactor = 0; 
        public Node leftLeaf;
        public Node rightLeaf;

        //Initalize a new node
        public Node(string[] words, int value)
        {   
            key = value;
            thisBook = new Book(words);
            rightLeaf = null;
            leftLeaf = null;
        }
        //Used when a tree wants to insert a new node
         public void InsertNewData(ref Node currentNode, string[] words, int key)
        {
            if (currentNode == null)
            {//when the location of a new node is found, it is placed here
                currentNode = new Node(words, key);
                Console.WriteLine("Insertion done");

            } 
            else if (currentNode.key < key)
            {//continues to search for node based on key value

                //if not found, dive deeper in tree
                InsertNewData(ref currentNode.rightLeaf, words, key);
                //once found, we need to update the height and balance of the parent node
                UpdateNode(currentNode);
                //once updated, we need to check if the balance threshold is reached, and if so rebalance the tree
                MaintainBalance(ref currentNode);
            }
            else if (currentNode.key > key) //I like the readableity here so i kept this detail
            {//continues to search for node based on key value

                //if not found, dive deeper in tree
                InsertNewData(ref currentNode.leftLeaf, words, key);
                //once found, we need to update the height and balance of the parent node
                UpdateNode(currentNode);
                //once updated, we need to check if the balance threshold is reached, and if so rebalance the tree
                MaintainBalance(ref currentNode);

            }
        }

        public void UpdateNode(Node currentNode)
        {
        //These are values used to store the height
        int r, l;
        //The flag affects the way the balance is calculated 
        bool flag = true;
        //Informs the user the node is being
        Console.WriteLine("Updateing the Node Key: " + currentNode.key);

        if(currentNode.rightLeaf == null)
        {//balance is raised for parent node of the new node.
            currentNode.balanceFactor += 1;
            r = 0;
            flag = false;
        }
        else{r = currentNode.rightLeaf.height;}

        if(currentNode.leftLeaf == null)
        {//balance is lowered for parent node of the new node. These mainly exist to work around a null node
            l = 0;
            currentNode.balanceFactor -= 1;
            flag = false;
        }
        else{ l = currentNode.leftLeaf.height; }

        if (flag) // we get the balance here for every other branching node
        {currentNode.balanceFactor = l - r;}
        //get the height of the node
        currentNode.height = GetMax(l , r) + 1;
        //Anounce the resulting balance for user
        Console.WriteLine("The balance of " + currentNode.key + " is " + currentNode.balanceFactor); 
        }

        public void MaintainBalance(ref Node currentNode)
        {   //here we the balance and call for rotation trees and subtrees.
            //if not, the focus skips this part.
            
            //right rotation
            if ( 1 < currentNode.balanceFactor ) 
            {
               //inform user of imbalance
               Console.WriteLine("This is a imbalance value");
               if(currentNode.leftLeaf.balanceFactor > 0)
                {//this is the double rotation function is for those imbalances have a "in-between key"
                    Rotation(ref currentNode.leftLeaf, "Left");
                    Rotation(ref currentNode, "Right");
                }//this is the simple rotation
                else{Rotation(ref currentNode, "Right");}
               
            }
            //left rotation
            if(currentNode.balanceFactor < -1)
            {
                Console.WriteLine("This is a imbalance value");
                if(currentNode.rightLeaf.balanceFactor > 0)
                {//this is the double rotation function is for those imbalances have a "in-between key"
                    Rotation(ref currentNode.rightLeaf, "Right");
                    Rotation(ref currentNode, "Left");
                }//this is the simple rotation
                else{Rotation(ref currentNode, "Left");}
            }  
            //Once done, the user needs to see the results
            Console.WriteLine("The height of " + currentNode.key + " is " +
            currentNode.height + " after maintainence");
            Console.WriteLine("The balance of " + currentNode.key + " is " +
            currentNode.balanceFactor + " after maintainence");

        }

        public void Rotation(ref Node currentNode, string direction)
        {//rotation based on direction
        //Right
            if(direction == "Right")
            {
                //This variable helps represent a node for display
                string leftKey;

                //the rotation itself
                Node child = currentNode.leftLeaf;
                currentNode.leftLeaf = child.rightLeaf;
                child.rightLeaf = currentNode;

                //everytime a balance has reached its limit, it is reset for later use 
                child.rightLeaf.balanceFactor = 0; 

                if(child.leftLeaf == null)
                {// this helps avoid null values that interrupt the code
                    child.rightLeaf.height = 0;
                    leftKey = "null";
                }
                else
                {//swaps the heights of the nodes
                    child.rightLeaf.height = child.leftLeaf.height;
                    leftKey = Convert.ToString(child.leftLeaf.key);
                }
                //Connect the swapped node to tree 
                currentNode = child;
                //update the branch
                UpdateNode(currentNode);
                //informs the user the new subtree order 
                Console.WriteLine("Rotated the nodes here. Current: " +
                    currentNode.key + " Left: " + leftKey + " Right: " + currentNode.rightLeaf.key ); 
            }
            else// Left
            {   
                //This variable helps represent a node for display
                string rightKey;

                //the rotation itself
                Node child = currentNode.rightLeaf;
                currentNode.rightLeaf = child.leftLeaf;
                child.leftLeaf = currentNode;

                //everytime a balance has reached its limit, it is reset for later use
                child.leftLeaf.balanceFactor = 0;
                if(child.rightLeaf == null)
                {// this helps avoid null values that interrupt the code
                    child.leftLeaf.height = 0;
                    rightKey = "null";
                }
                else
                {//swaps the heights of the nodes
                    child.leftLeaf.height = child.rightLeaf.height;
                    rightKey = Convert.ToString(child.rightLeaf.key);
                } 
                //Connect the swapped node to tree
                currentNode = child;
                UpdateNode(currentNode);
                //informs the user the new subtree order
                Console.WriteLine("Rotated the nodes here. Current: " +
                    currentNode.key + " Left: " + currentNode.leftLeaf.key + " Right: " + rightKey);
            }        
        }

        public int GetMax(int l, int r)
        {//simply returns the values with the largest height from the left and right nodes  
            if (l > r)
            {
            return l;
            }
            else{return r;}
        }

    } 
}
